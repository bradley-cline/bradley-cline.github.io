//
//  main.cpp
//  FlowAssessment
//
//  Created by Brad on 9/15/24.
//
#include "ShoppingCart.h"

#include <iostream>

using std::cin;
using std::cout;
using std::endl;

void toLower(string& str)
{
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
}


void clearCin()
{
    cin.clear();
    cin.ignore(1000, '\n');
}


void welcome()
{
    cout << "------------------------------" << endl;
    cout << "Welcome to your shopping cart!" << endl;
    cout << "------------------------------" << endl;
    
    cout << "\nThe following commands are available:" << endl;
    cout << "add" << endl;
    cout << "summary" << endl;
    cout << "save" << endl;
    cout << "exit" << endl;
}


int main(int argc, const char * argv[]) {
    ShoppingCart cart = ShoppingCart();
    welcome();
    string userInput;
    
    cout << "\nType a command: ";
    getline(cin, userInput);
    toLower(userInput);

    // Keep cart open until user chooses to exit
    while (userInput != "exit")
    {
        if (userInput == "add") {
            // Default to adding a single item
            string addAnother = "yes";
            
            while (addAnother == "yes") {
                string itemType;
                string title;
                
                cout << "What type of item would you like to add (CD, Book, Magazine, or Other)?" << endl;
                cout << "Item type: ";
                getline(cin, itemType);
                toLower(itemType);
                
                cout << "debug itemtype: " << itemType << endl;
                
                if (itemType == "cd") {
                    string artist;
                    
                    cout << "Album title? ";
                    getline(cin, title);
                    cout << "Artist? ";
                    getline(cin, artist);
                    
                    cart.addItem(title, artist);
                } else if (itemType == "book") {
                    string author;
                    int pages;
                    
                    cout << "Title? ";
                    getline(cin, title);
                    cout << "Author? ";
                    getline(cin, author);
                    cout << "How many pages? ";
                    cin >> pages;
                    
                    // Check for integer input
                    while (!cin)
                    {
                        clearCin();
                        cout << "Page count must be a positive integer: ";
                        cin >> pages;
                    }
                    
                    clearCin();
                    cart.addItem(title, author, pages);
                } else if (itemType == "magazine") {
                    int pages;
                    
                    cout << "Title? ";
                    getline(cin, title);
                    cout << "What issue? ";
                    cin >> pages;
                    
                    // Check for integer input
                    while (!cin)
                    {
                        clearCin();
                        cout << "Issue must be a positive integer: ";
                        cin >> pages;
                    }
                    
                    clearCin();
                    cart.addItem(title, pages);
                } else if (itemType == "other") {
                    cout << "Title or name of item? ";
                    getline(cin, title);
                    cart.addItem(title);
                } else {
                    cout << "invalid item type" << endl;
                }
                
                cout << "Would you like to add another item (yes/no)? ";
                getline(cin, addAnother, '\n');
            }
        } else if (userInput == "summary") {
            cart.summarizeContents();
        } else if (userInput == "save") {
            cart.saveCartToFile();
        } else {
            cout << "Command invalid. Please enter a valid command: add, summary, save, exit." << endl;
        }
        
        cout << "\nType a command: ";
        getline(cin, userInput);
        toLower(userInput);
    }
    
    cout << "Thanks for shopping!" << endl;
    
    return 0;
}
