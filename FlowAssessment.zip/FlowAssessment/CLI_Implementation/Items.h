//
//  Items.h
//

#ifndef Items_h
#define Items_h

#include <string>

using std::string;


/*
 * Item Class, abstract base class
 */
class Item {
protected:
    string title;
    
public:
    // All items and derived items must have a title
    Item() = delete;
    Item(string itemTitle): title(itemTitle) {};
    virtual ~Item() = default;
    virtual string getItemSummary() = 0;
};


/*
 * CD Class, derived from Item class
 * Has album title and artist
 */
class CD : public Item {
    const string type = "CD";
    string artist;
    
public:
    CD() = delete;
    CD(string title, string artist) : Item(title), artist(artist) {};
    
    string getItemSummary() override
    {
        string summary = type + ": \"" + title + "\" by " + artist;
        return summary;
    }
};


/*
 * Book Class, derived from Item class
 * Has title, author, and page count
 */
class Book : public Item {
    const string type = "Book";
    string author = "Joe Schmoe";
    int pages;
    
public:
    Book() = delete;
    Book(string title, string author, int pages) : Item (title), author(author), pages(pages) {};
    
    string getItemSummary() override
    {
        string summary = type + ": \"" + title + "\" by " + author;
        summary += ", Length: " + std::to_string(pages) + " pages";
        return summary;
    }
};


/*
 * Magazine Class, derived from Item class
 * Has title and issue number
 */
class Magazine : public Item {
    const string type = "Magazine";
    int issue;
    
public:
    Magazine() = delete;
    Magazine(string title, int issue) : Item (title), issue(issue) {};
    
    string getItemSummary() override
    {
        string summary = type + ": \"" + title + "\" issue #" + std::to_string(issue);
        return summary;
    }
};


/*
 * GenericItem Class, derived from Item class
 * Has title only. Could be any non-cd/book/magazine item
 */
class GenericItem : public Item {
    const string type = "Other";
    int issue;
    
public:
    GenericItem() = delete;
    GenericItem(string title) : Item (title) {};
    
    string getItemSummary() override
    {
        return type + ": " + title;
    }
};

#endif /* Items_h */
