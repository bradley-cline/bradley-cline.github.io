#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "ShoppingCart.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Confine input on numeric fields
    ui->pageCount->setValidator( new QIntValidator(0, 10000, this) );
    ui->issueNumber->setValidator( new QIntValidator(0, 10000, this) );

    connect(ui->addCDButton, &QPushButton::released, this, &MainWindow::AddCD);
    connect(ui->addBookButton, &QPushButton::released, this, &MainWindow::AddBook);
    connect(ui->addMagazineButton, &QPushButton::released, this, &MainWindow::AddMagazine);
    connect(ui->addOtherButton, &QPushButton::released, this, &MainWindow::AddOtherItem);
    connect(ui->saveCart, &QPushButton::released, this, &MainWindow::SaveCartToFile);
    connect(this, &MainWindow::contentsUpdated, this, &MainWindow::RefreshCartSummary);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::RefreshCartSummary()
{
    cart.updateContentsList(ui->cartContents);
}

void MainWindow::AddCD()
{
    if (ui->albumTitle->text().isEmpty() || ui->artist->text().isEmpty())
    {
        QMessageBox warning;
        warning.setText("At least one field is empty.");
        warning.setInformativeText("You must complete all fields for the object you want to add to the cart");
        warning.exec();
        return;
    }

    cart.addItem(ui->albumTitle->text().toStdString(), ui->artist->text().toStdString());
    ui->albumTitle->clear();
    ui->artist->clear();

    emit contentsUpdated();
}

void MainWindow::AddBook()
{
    if (ui->bookTitle->text().isEmpty() || ui->author->text().isEmpty() || ui->pageCount->text().isEmpty())
    {
        QMessageBox warning;
        warning.setText("At least one field is empty.");
        warning.setInformativeText("You must complete all fields for the object you want to add to the cart");
        warning.exec();
        return;
    }

    cart.addItem(ui->bookTitle->text().toStdString(), ui->author->text().toStdString(), ui->pageCount->text().toInt());
    ui->bookTitle->clear();
    ui->author->clear();
    ui->pageCount->clear();

    emit contentsUpdated();
}

void MainWindow::AddMagazine()
{
    if (ui->magazineTitle->text().isEmpty() || ui->issueNumber->text().isEmpty())
    {
        QMessageBox warning;
        warning.setText("At least one field is empty.");
        warning.setInformativeText("You must complete all fields for the object you want to add to the cart");
        warning.exec();
        return;
    }

    cart.addItem(ui->magazineTitle->text().toStdString(), ui->issueNumber->text().toInt());
    ui->magazineTitle->clear();
    ui->issueNumber->clear();

    emit contentsUpdated();
}

void MainWindow::AddOtherItem()
{
    if (ui->otherTitle->text().isEmpty())
    {
        QMessageBox warning;
        warning.setText("Name is missing for Other Object");
        warning.setInformativeText("You must complete all fields for the object you want to add to the cart");
        warning.exec();
        return;
    }

    cart.addItem(ui->otherTitle->text().toStdString());
    ui->otherTitle->clear();

    emit contentsUpdated();
}

void MainWindow::SaveCartToFile()
{
    cart.saveCartToFile();

    QMessageBox info;
    info.setText("Cart contents saved");
    info.setInformativeText("Saved to file CartContents.txt in the working directory");
    info.exec();
}
