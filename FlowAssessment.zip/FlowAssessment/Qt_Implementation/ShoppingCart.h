//
//  ShoppingCart.h
//

#ifndef ShoppingCart_h
#define ShoppingCart_h

#include "Items.h"
#include <vector>
#include <string>
#include <iostream>
#include <memory>
#include <fstream>
#include <QListWidget>

using std::cout;
using std::endl;
using std::vector;
using std::unique_ptr;
using std::make_unique;
using std::ofstream;
using std::string;

class ShoppingCart {
    vector<unique_ptr<Item>> items;
    
public:
    // For adding generic items to the cart
    void addItem(string title)
    {
        items.push_back(make_unique<GenericItem>(title));
        cout << "Added " << title << " to cart" << endl;
    }
    
    // For adding CDs to the cart
    void addItem(string title, string artist)
    {
        items.push_back(make_unique<CD>(title, artist));
        cout << "Added CD \"" << title << "\" to cart" << endl;
    }
    
    // For adding Books to the cart
    void addItem(string title, string author, int pages)
    {
        items.push_back(make_unique<Book>(title, author, pages));
        cout << "Added \"" << title << "\" by " << author << " to cart" << endl;
    }
    
    // For adding Magazines to the cart
    void addItem(string title, int issue)
    {
        items.push_back(make_unique<Magazine>(title, issue));
        cout << "Added \"" << title << "\" issue #" << issue << " to cart" << endl;
    }
       
    // Spits out a summary of the cart's current contents
    void summarizeContents()
    {
        if (cartIsEmpty())
            return;
        
        cout << "\nThe cart contains the following items:" << endl;
        
        for (auto& x : items)
        {
            cout << "* " << x->getItemSummary()<< endl;
        }
    }

    void updateContentsList(QListWidget* contentsList)
    {
        contentsList->clear();
        for (auto& x : items)
        {
            contentsList->addItem(QString::fromStdString(x->getItemSummary()));
        }
    }
    
    // Checks for empty cart. Returns true if empty
    bool cartIsEmpty()
    {
        if (items.empty()) {
            cout << "Your cart is empty!" << endl;
            return true;
        }
        
        return false;
    }
    
    // Saves a summary of the cart's current contents to file named "CartContents.txt" in the
    // current working directory
    void saveCartToFile()
    {
        // Open output file
        ofstream outFile;
        outFile.open("CartContents.txt");
        
        // Check for empty cart
        if (cartIsEmpty())
            return;
        
        // Write cart contents to file
        outFile << "The cart contains the following items:" << endl;
        for (auto& x : items)
        {
            outFile << "* " << x->getItemSummary()<< endl;
        }
        
        outFile.close();

        cout << "A summary of the shopping cart contents has been saved to file 'CartContents.txt' in the working directory" << endl;
    }
};

#endif /* ShoppingCart_h */
