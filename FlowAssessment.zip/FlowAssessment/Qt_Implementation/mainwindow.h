#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ShoppingCart.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    ShoppingCart cart;

private slots:
    void RefreshCartSummary();
    void AddCD();
    void AddBook();
    void AddMagazine();
    void AddOtherItem();
    void SaveCartToFile();

signals:
    void contentsUpdated();
};
#endif // MAINWINDOW_H
